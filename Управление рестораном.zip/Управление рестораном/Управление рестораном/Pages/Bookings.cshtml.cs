using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class BookingsModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public BookingsModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    [BindProperty(SupportsGet = true)]
    public int? BookingId { get; set; }

    [BindProperty]
    public string GuestName { get; set; } = string.Empty;

    [BindProperty]
    public string Phone { get; set; } = string.Empty;

    [BindProperty]
    public string VisitDate { get; set; } = DateTime.Now.ToString("dd.MM.yyyy");

    [BindProperty]
    public string VisitTime { get; set; } = "19:00";

    [BindProperty]
    public int GuestCount { get; set; } = 2;

    [BindProperty]
    public int? TableNumber { get; set; }

    [BindProperty]
    public string Preference { get; set; } = string.Empty;

    [BindProperty]
    public string Comment { get; set; } = string.Empty;

    [TempData]
    public string? StatusMessage { get; set; }

    public IReadOnlyList<Booking> Bookings { get; private set; } = Array.Empty<Booking>();
    public Booking? SelectedBooking { get; private set; }
    public int ConfirmedCount => Bookings.Count(b => b.Status == BookingStatus.Confirmed);
    public int NewCount => Bookings.Count(b => b.Status == BookingStatus.New);
    public int CancelledCount => Bookings.Count(b => b.Status == BookingStatus.Cancelled);

    public void OnGet()
    {
        LoadData();
    }

    public IActionResult OnPostAdd()
    {
        if (!DateOnly.TryParse(VisitDate, out var date))
        {
            date = DateOnly.FromDateTime(DateTime.Now);
        }

        if (!TimeOnly.TryParse(VisitTime, out var time))
        {
            time = new TimeOnly(19, 0);
        }

        var error = _stateService.AddBooking(
            string.IsNullOrWhiteSpace(GuestName) ? "Новый клиент" : GuestName,
            string.IsNullOrWhiteSpace(Phone) ? "Не указан" : Phone,
            date,
            time,
            GuestCount <= 0 ? 2 : GuestCount,
            TableNumber,
            Preference,
            Comment,
            out var bookingId);

        if (error is not null)
        {
            StatusMessage = error;
            return RedirectToPage();
        }

        return RedirectToPage(new { bookingId });
    }

    public IActionResult OnPostSetStatus(int id, BookingStatus status)
    {
        _stateService.SetBookingStatus(id, status);
        return RedirectToPage(new { bookingId = id });
    }

    public IActionResult OnPostDelete(int id)
    {
        _stateService.DeleteBooking(id);
        return RedirectToPage();
    }

    public string GetBookingStatusLabel(BookingStatus status) => status switch
    {
        BookingStatus.New => "Новая",
        BookingStatus.Confirmed => "Подтверждено",
        BookingStatus.Cancelled => "Отмена",
        _ => "Неизвестно"
    };

    public string GetBookingBadgeClass(BookingStatus status) => status switch
    {
        BookingStatus.New => "badge-soft--warning",
        BookingStatus.Confirmed => "badge-soft--success",
        BookingStatus.Cancelled => "badge-soft--danger",
        _ => "badge-soft--warning"
    };

    private void LoadData()
    {
        Bookings = _stateService.GetBookings(DateTime.Now);
        SelectedBooking = BookingId.HasValue ? Bookings.FirstOrDefault(b => b.Id == BookingId.Value) : Bookings.FirstOrDefault();
    }
}
