using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class ReportsModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public ReportsModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    [BindProperty(SupportsGet = true)]
    public bool ShowSummary { get; set; }

    public ReportsViewData Report { get; private set; } = new();

    public void OnGet()
    {
        Report = _stateService.GetReportsData(DateTime.Now);
    }
}
