using Microsoft.EntityFrameworkCore;
using Управление_рестораном.Data;
using Управление_рестораном.Data.Entities;
using Управление_рестораном.Models;

namespace Управление_рестораном.Services;

public class RestaurantStateService
{
    private readonly RestaurantDbContext _db;

    public RestaurantStateService(RestaurantDbContext db)
    {
        _db = db;
    }

    public DashboardViewData GetDashboardData(DateTime now)
    {
        var today = now.Date;
        var yesterday = today.AddDays(-1);
        var startOfWeek = GetStartOfWeek(today);

        var completedOrders = _db.Заказы
            .Include(x => x.Позиции)
            .Where(x => x.Статус == "Завершён" && x.ДатаЗакрытия.HasValue)
            .ToList();

        var todayRevenue = completedOrders
            .Where(x => x.ДатаЗакрытия!.Value.Date == today)
            .Sum(x => x.Позиции.Sum(p => p.Количество * p.ЦенаЗаЕдиницу));

        var yesterdayRevenue = completedOrders
            .Where(x => x.ДатаЗакрытия!.Value.Date == yesterday)
            .Sum(x => x.Позиции.Sum(p => p.Количество * p.ЦенаЗаЕдиницу));

        var weeklyRevenue = Enumerable.Range(0, 7)
            .Select(offset =>
            {
                var day = startOfWeek.AddDays(offset);
                return new RevenuePoint
                {
                    Label = GetDayLabel(day.DayOfWeek),
                    Amount = completedOrders
                        .Where(x => x.ДатаЗакрытия!.Value.Date == day)
                        .Sum(x => x.Позиции.Sum(p => p.Количество * p.ЦенаЗаЕдиницу))
                };
            })
            .ToList();

        var maxRevenue = weeklyRevenue.Max(x => x.Amount);
        foreach (var point in weeklyRevenue)
        {
            point.HeightPercent = maxRevenue == 0 ? 8 : Math.Max(8, point.Amount / maxRevenue * 100);
        }

        var activeOrders = _db.Заказы.Count(x => x.Статус == "Готовится" || x.Статус == "Готов");
        var occupiedTables = _db.Столики.Count(x => x.Статус == "Занят");
        var totalTables = _db.Столики.Count();

        return new DashboardViewData
        {
            TodayRevenue = todayRevenue,
            RevenueDeltaPercent = yesterdayRevenue == 0 ? 0 : Math.Round((todayRevenue - yesterdayRevenue) / yesterdayRevenue * 100, 0),
            ActiveOrders = activeOrders,
            ActiveOrdersDelta = 0,
            OccupiedTables = occupiedTables,
            TotalTables = totalTables,
            OccupiedPercent = totalTables == 0 ? 0 : (int)Math.Round((double)occupiedTables / totalTables * 100),
            DishCount = _db.Блюда.Count(),
            DishCountDelta = _db.Блюда.Count(x => x.Доступно),
            WeeklyRevenue = weeklyRevenue,
            WeeklyMaxRevenue = maxRevenue
        };
    }

    public IReadOnlyList<Dish> GetDishes(string? search = null)
    {
        return _db.Блюда
            .Where(x => string.IsNullOrWhiteSpace(search) || x.Название.Contains(search))
            .OrderBy(x => x.Категория)
            .ThenBy(x => x.Название)
            .Select(MapDish)
            .ToList();
    }

    public string? AddSampleDish()
    {
        var variants = new[]
        {
            new { Name = "Рамен с курицей", Category = "Супы", Price = 490m, Cost = 180m },
            new { Name = "Фокачча с песто", Category = "Горячее", Price = 320m, Cost = 110m },
            new { Name = "Лимонад облепиха сезонный", Category = "Напитки", Price = 280m, Cost = 90m },
            new { Name = "Наполеон", Category = "Десерты", Price = 360m, Cost = 135m }
        };

        var candidate = variants.FirstOrDefault(v => !_db.Блюда.Any(x => x.Название == v.Name));
        if (candidate is null)
        {
            return "Такое блюдо уже есть в меню.";
        }

        _db.Блюда.Add(new БлюдоСущность
        {
            Название = candidate.Name,
            Категория = candidate.Category,
            Цена = candidate.Price,
            Себестоимость = candidate.Cost,
            Доступно = true
        });
        _db.SaveChanges();

        return null;
    }

    public string AddDish(string name, DishCategory category, decimal price, decimal costPrice)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return "Нужно указать название блюда.";
        }

        if (_db.Блюда.Any(x => x.Название == name.Trim()))
        {
            return "Такое блюдо уже есть в меню.";
        }

        if (price <= 0)
        {
            return "Цена должна быть больше нуля.";
        }

        if (costPrice < 0)
        {
            return "Себестоимость не может быть отрицательной.";
        }

        _db.Блюда.Add(new БлюдоСущность
        {
            Название = name.Trim(),
            Категория = MapCategory(category),
            Цена = price,
            Себестоимость = costPrice,
            Доступно = true
        });
        _db.SaveChanges();

        return "Блюдо добавлено в меню.";
    }

    public void ToggleDishAvailability(int id)
    {
        var dish = _db.Блюда.FirstOrDefault(x => x.ИдБлюда == id);
        if (dish is null) return;
        dish.Доступно = !dish.Доступно;
        _db.SaveChanges();
    }

    public void ChangeDishPrice(int id, decimal delta)
    {
        var dish = _db.Блюда.FirstOrDefault(x => x.ИдБлюда == id);
        if (dish is null) return;
        dish.Цена = Math.Max(100, dish.Цена + delta);
        _db.SaveChanges();
    }

    public void RemoveDish(int id)
    {
        var dish = _db.Блюда.FirstOrDefault(x => x.ИдБлюда == id);
        if (dish is null) return;
        _db.Блюда.Remove(dish);
        _db.SaveChanges();
    }

    public IReadOnlyList<RestaurantOrder> GetActiveOrders()
    {
        return _db.Заказы
            .Include(x => x.Столик)
            .Include(x => x.Позиции)
            .ThenInclude(x => x.Блюдо)
            .Where(x => x.Статус == "Готовится" || x.Статус == "Готов")
            .OrderByDescending(x => x.ДатаСоздания)
            .ToList()
            .Select(MapOrder)
            .ToList();
    }

    public IReadOnlyList<RestaurantOrder> GetOrderHistory(HistoryPeriod period, DateTime now)
    {
        var query = _db.Заказы
            .Include(x => x.Столик)
            .Include(x => x.Позиции)
            .ThenInclude(x => x.Блюдо)
            .Where(x => (x.Статус == "Завершён" || x.Статус == "Отменён") && x.ДатаЗакрытия.HasValue);

        query = period switch
        {
            HistoryPeriod.Today => query.Where(x => x.ДатаЗакрытия!.Value.Date == now.Date),
            HistoryPeriod.Week => query.Where(x => x.ДатаЗакрытия!.Value.Date >= GetStartOfWeek(now.Date)),
            HistoryPeriod.Month => query.Where(x => x.ДатаЗакрытия!.Value.Date >= new DateTime(now.Year, now.Month, 1)),
            _ => query
        };

        return query
            .OrderByDescending(x => x.ДатаЗакрытия)
            .ToList()
            .Select(MapOrder)
            .ToList();
    }

    public string? AddOrder(int tableNumber, List<int> dishIds, string comment, DateTime now)
    {
        var table = _db.Столики.FirstOrDefault(x => x.НомерСтолика == tableNumber);
        if (table is null)
        {
            return "Такого столика не существует.";
        }

        if (table.Статус == "Забронирован")
        {
            return "Этот столик сейчас забронирован, выбери другой.";
        }

        var dishes = _db.Блюда.Where(x => dishIds.Contains(x.ИдБлюда)).ToList();
        if (dishes.Count == 0)
        {
            return "Нужно выбрать хотя бы одно блюдо.";
        }

        var unavailable = dishes.FirstOrDefault(x => !x.Доступно);
        if (unavailable is not null)
        {
            return $"Блюдо \"{unavailable.Название}\" сейчас недоступно.";
        }

        var order = new ЗаказСущность
        {
            ИдСтолика = table.ИдСтолика,
            Статус = "Готовится",
            Комментарий = comment,
            ДатаСоздания = now
        };

        _db.Заказы.Add(order);
        _db.SaveChanges();

        foreach (var group in dishes.GroupBy(x => x.ИдБлюда))
        {
            var dish = group.First();
            _db.ПозицииЗаказа.Add(new ПозицияЗаказаСущность
            {
                ИдЗаказа = order.ИдЗаказа,
                ИдБлюда = dish.ИдБлюда,
                Количество = group.Count(),
                ЦенаЗаЕдиницу = dish.Цена,
                СебестоимостьЗаЕдиницу = dish.Себестоимость
            });
        }

        table.Статус = "Занят";
        table.ЗанятоМест = Math.Max(2, Math.Min(table.Вместимость, table.ЗанятоМест == 0 ? 2 : table.ЗанятоМест));
        table.ВремяСтатуса = now;
        table.ВремяБрони = null;

        _db.SaveChanges();
        return null;
    }

    public IReadOnlyList<Dish> GetAvailableDishes()
    {
        return _db.Блюда.Where(x => x.Доступно).OrderBy(x => x.Название).Select(MapDish).ToList();
    }

    public IReadOnlyList<DiningTable> GetTablesForOrders()
    {
        return _db.Столики
            .Where(x => x.Статус != "Забронирован")
            .OrderBy(x => x.НомерСтолика)
            .Select(MapTable)
            .ToList();
    }

    public void AdvanceOrder(int id, DateTime now)
    {
        var order = _db.Заказы.FirstOrDefault(x => x.ИдЗаказа == id);
        if (order is null) return;

        if (order.Статус == "Готовится")
        {
            order.Статус = "Готов";
        }
        else if (order.Статус == "Готов")
        {
            order.Статус = "Завершён";
            order.ДатаЗакрытия = now;
        }

        _db.SaveChanges();
    }

    public void CancelOrder(int id, DateTime now)
    {
        var order = _db.Заказы.FirstOrDefault(x => x.ИдЗаказа == id);
        if (order is null) return;
        order.Статус = "Отменён";
        order.ДатаЗакрытия = now;
        _db.SaveChanges();
    }

    public IReadOnlyList<DiningTable> GetTables()
    {
        return _db.Столики.OrderBy(x => x.НомерСтолика).Select(MapTable).ToList();
    }

    public void SetTableStatus(int number, TableStatus status, DateTime now)
    {
        var table = _db.Столики.FirstOrDefault(x => x.НомерСтолика == number);
        if (table is null) return;

        table.Статус = MapTableStatus(status);
        table.ВремяСтатуса = now;

        switch (status)
        {
            case TableStatus.Free:
                table.ЗанятоМест = 0;
                table.ВремяБрони = null;
                break;
            case TableStatus.Occupied:
                table.ЗанятоМест = Math.Max(2, Math.Min(table.Вместимость, table.ЗанятоМест == 0 ? table.Вместимость / 2 : table.ЗанятоМест));
                table.ВремяБрони = null;
                break;
            case TableStatus.Reserved:
                table.ЗанятоМест = 0;
                break;
        }

        _db.SaveChanges();
    }

    public IReadOnlyList<Booking> GetBookings(DateTime now)
    {
        var today = DateOnly.FromDateTime(now);
        return _db.Брони
            .Include(x => x.Клиент)
            .Include(x => x.Столик)
            .Where(x => x.ДатаБрони >= today)
            .OrderBy(x => x.ДатаБрони)
            .ThenBy(x => x.ВремяБрони)
            .ToList()
            .Select(MapBooking)
            .ToList();
    }

    public string? AddBooking(string guestName, string phone, DateOnly visitDate, TimeOnly visitTime, int guestCount, int? tableNumber, string preference, string comment, out int bookingId)
    {
        bookingId = 0;

        СтоликСущность? table = null;
        if (tableNumber.HasValue)
        {
            table = _db.Столики.FirstOrDefault(x => x.НомерСтолика == tableNumber.Value);
            if (table is null)
            {
                return "Такого столика не существует.";
            }

            if (table.Вместимость < guestCount)
            {
                return $"Столик #{table.НомерСтолика} рассчитан только на {table.Вместимость} гостей.";
            }

            if (table.Статус == "Занят")
            {
                return $"Столик #{table.НомерСтолика} уже занят.";
            }

            if (table.Статус == "Забронирован")
            {
                return $"Столик #{table.НомерСтолика} уже забронирован.";
            }
        }

        var customer = new КлиентСущность
        {
            ФИО = guestName,
            Телефон = phone
        };
        _db.Клиенты.Add(customer);
        _db.SaveChanges();

        var booking = new БроньСущность
        {
            ИдКлиента = customer.ИдКлиента,
            ИдСтолика = table?.ИдСтолика,
            ДатаБрони = visitDate,
            ВремяБрони = visitTime,
            КоличествоГостей = guestCount,
            Предпочтение = preference,
            Комментарий = comment,
            Статус = "Новая",
            ДатаСоздания = DateTime.Now
        };

        _db.Брони.Add(booking);
        if (table is not null)
        {
            table.Статус = "Забронирован";
            table.ВремяБрони = visitDate.ToDateTime(visitTime);
            table.ЗанятоМест = 0;
        }

        _db.SaveChanges();
        bookingId = booking.ИдБрони;
        return null;
    }

    public void SetBookingStatus(int id, BookingStatus status)
    {
        var booking = _db.Брони.FirstOrDefault(x => x.ИдБрони == id);
        if (booking is null) return;
        booking.Статус = MapBookingStatus(status);
        _db.SaveChanges();
    }

    public void DeleteBooking(int id)
    {
        var booking = _db.Брони.FirstOrDefault(x => x.ИдБрони == id);
        if (booking is null) return;

        if (booking.ИдСтолика.HasValue)
        {
            var table = _db.Столики.FirstOrDefault(x => x.ИдСтолика == booking.ИдСтолика.Value);
            if (table is not null && table.Статус == "Забронирован")
            {
                table.Статус = "Свободен";
                table.ВремяБрони = null;
            }
        }

        _db.Брони.Remove(booking);
        _db.SaveChanges();
    }

    public ReportsViewData GetReportsData(DateTime now)
    {
        var weekStart = GetStartOfWeek(now.Date);
        var completedOrders = _db.Заказы
            .Include(x => x.Столик)
            .Include(x => x.Позиции)
            .ThenInclude(x => x.Блюдо)
            .Where(x => x.Статус == "Завершён" && x.ДатаЗакрытия.HasValue && x.ДатаЗакрытия.Value.Date >= weekStart)
            .ToList();

        var popularDishes = completedOrders
            .SelectMany(x => x.Позиции)
            .GroupBy(x => x.Блюдо.Название)
            .Select(x => (DishName: x.Key, Quantity: x.Sum(i => i.Количество)))
            .OrderByDescending(x => x.Quantity)
            .ToList();

        var topDish = popularDishes.FirstOrDefault();
        var confirmedBookings = _db.Брони.Count(x => x.Статус == "Подтверждена");
        var cancelledBookings = _db.Брони.Count(x => x.Статус == "Отменена");
        var totalGuests = _db.Брони.Where(x => x.Статус != "Отменена").Sum(x => x.КоличествоГостей);
        var revenue = completedOrders.Sum(x => x.Позиции.Sum(p => p.Количество * p.ЦенаЗаЕдиницу));
        var costs = completedOrders.Sum(x => x.Позиции.Sum(p => p.Количество * p.СебестоимостьЗаЕдиницу));

        return new ReportsViewData
        {
            WeeklyRevenue = revenue,
            WeeklyCosts = costs,
            WeeklyProfit = revenue - costs,
            TopDishName = topDish.DishName ?? "Нет данных",
            TopDishOrders = topDish.Quantity,
            AverageReceipt = completedOrders.Count == 0 ? 0 : revenue / completedOrders.Count,
            CompletedOrders = completedOrders.Count,
            ConfirmedBookings = confirmedBookings,
            CancelledBookings = cancelledBookings,
            TotalGuests = totalGuests,
            PopularDishes = popularDishes.Take(5).ToList(),
            SummaryLines = new List<string>
            {
                $"Выручка: {revenue:N0} ₽",
                $"Себестоимость: {costs:N0} ₽",
                $"Прибыль: {revenue - costs:N0} ₽",
                $"Клиентов по броням: {totalGuests}",
                $"Подтверждено броней: {confirmedBookings}",
                $"Отменено броней: {cancelledBookings}",
                $"Выполнено заказов: {completedOrders.Count}"
            }
        };
    }

    private static Dish MapDish(БлюдоСущность x) => new()
    {
        Id = x.ИдБлюда,
        Name = x.Название,
        Category = ParseCategory(x.Категория),
        Price = x.Цена,
        CostPrice = x.Себестоимость,
        IsAvailable = x.Доступно
    };

    private static DiningTable MapTable(СтоликСущность x) => new()
    {
        Number = x.НомерСтолика,
        Capacity = x.Вместимость,
        OccupiedSeats = x.ЗанятоМест,
        Status = ParseTableStatus(x.Статус),
        StatusSince = x.ВремяСтатуса,
        ReservedFor = x.ВремяБрони
    };

    private static Booking MapBooking(БроньСущность x) => new()
    {
        Id = x.ИдБрони,
        GuestName = x.Клиент.ФИО,
        Phone = x.Клиент.Телефон,
        VisitDate = x.ДатаБрони,
        VisitTime = x.ВремяБрони,
        GuestCount = x.КоличествоГостей,
        TableNumber = x.Столик?.НомерСтолика,
        Preference = x.Предпочтение ?? string.Empty,
        Comment = x.Комментарий ?? string.Empty,
        Status = ParseBookingStatus(x.Статус),
        CreatedAt = x.ДатаСоздания
    };

    private static RestaurantOrder MapOrder(ЗаказСущность x) => new()
    {
        Id = x.ИдЗаказа,
        TableNumber = x.Столик.НомерСтолика,
        CreatedAt = x.ДатаСоздания,
        ClosedAt = x.ДатаЗакрытия,
        Status = ParseOrderStatus(x.Статус),
        Comment = x.Комментарий ?? string.Empty,
        Items = x.Позиции.Select(p => new OrderItem
        {
            DishId = p.ИдБлюда,
            DishName = p.Блюдо.Название,
            UnitPrice = p.ЦенаЗаЕдиницу,
            UnitCost = p.СебестоимостьЗаЕдиницу,
            Quantity = p.Количество
        }).ToList()
    };

    private static string MapCategory(DishCategory category) => category switch
    {
        DishCategory.Soups => "Супы",
        DishCategory.Salads => "Салаты",
        DishCategory.HotMeals => "Горячее",
        DishCategory.Desserts => "Десерты",
        DishCategory.Drinks => "Напитки",
        _ => "Напитки"
    };

    private static DishCategory ParseCategory(string category) => category switch
    {
        "Супы" => DishCategory.Soups,
        "Салаты" => DishCategory.Salads,
        "Горячее" => DishCategory.HotMeals,
        "Десерты" => DishCategory.Desserts,
        "Напитки" => DishCategory.Drinks,
        _ => DishCategory.Drinks
    };

    private static string MapTableStatus(TableStatus status) => status switch
    {
        TableStatus.Free => "Свободен",
        TableStatus.Occupied => "Занят",
        TableStatus.Reserved => "Забронирован",
        _ => "Свободен"
    };

    private static TableStatus ParseTableStatus(string status) => status switch
    {
        "Свободен" => TableStatus.Free,
        "Занят" => TableStatus.Occupied,
        "Забронирован" => TableStatus.Reserved,
        _ => TableStatus.Free
    };

    private static string MapBookingStatus(BookingStatus status) => status switch
    {
        BookingStatus.New => "Новая",
        BookingStatus.Confirmed => "Подтверждена",
        BookingStatus.Cancelled => "Отменена",
        _ => "Новая"
    };

    private static BookingStatus ParseBookingStatus(string status) => status switch
    {
        "Новая" => BookingStatus.New,
        "Подтверждена" => BookingStatus.Confirmed,
        "Отменена" => BookingStatus.Cancelled,
        _ => BookingStatus.New
    };

    private static OrderStatus ParseOrderStatus(string status) => status switch
    {
        "Готовится" => OrderStatus.Cooking,
        "Готов" => OrderStatus.Ready,
        "Завершён" => OrderStatus.Completed,
        "Отменён" => OrderStatus.Cancelled,
        _ => OrderStatus.Cooking
    };

    private static DateTime GetStartOfWeek(DateTime date)
    {
        var diff = (7 + (date.DayOfWeek - DayOfWeek.Monday)) % 7;
        return date.AddDays(-diff).Date;
    }

    private static string GetDayLabel(DayOfWeek dayOfWeek) => dayOfWeek switch
    {
        DayOfWeek.Monday => "Пн",
        DayOfWeek.Tuesday => "Вт",
        DayOfWeek.Wednesday => "Ср",
        DayOfWeek.Thursday => "Чт",
        DayOfWeek.Friday => "Пт",
        DayOfWeek.Saturday => "Сб",
        DayOfWeek.Sunday => "Вс",
        _ => string.Empty
    };
}
