namespace Управление_рестораном.Models;

public enum DishCategory
{
    Soups,
    Salads,
    HotMeals,
    Desserts,
    Drinks
}

public enum OrderStatus
{
    Cooking,
    Ready,
    Completed,
    Cancelled
}

public enum TableStatus
{
    Free,
    Occupied,
    Reserved
}

public enum BookingStatus
{
    New,
    Confirmed,
    Cancelled
}

public enum HistoryPeriod
{
    Today,
    Week,
    Month,
    All
}

public class Dish
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DishCategory Category { get; set; }
    public decimal Price { get; set; }
    public decimal CostPrice { get; set; }
    public bool IsAvailable { get; set; }
}

public class OrderItem
{
    public int DishId { get; set; }
    public string DishName { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public decimal UnitCost { get; set; }
    public int Quantity { get; set; }
    public decimal TotalPrice => UnitPrice * Quantity;
    public decimal TotalCost => UnitCost * Quantity;
}

public class RestaurantOrder
{
    public int Id { get; set; }
    public int TableNumber { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public OrderStatus Status { get; set; }
    public string Comment { get; set; } = string.Empty;
    public List<OrderItem> Items { get; set; } = new();
    public decimal TotalAmount => Items.Sum(item => item.TotalPrice);
    public decimal TotalCost => Items.Sum(item => item.TotalCost);
}

public class DiningTable
{
    public int Number { get; set; }
    public int Capacity { get; set; }
    public int OccupiedSeats { get; set; }
    public TableStatus Status { get; set; }
    public DateTime? StatusSince { get; set; }
    public DateTime? ReservedFor { get; set; }
}

public class Booking
{
    public int Id { get; set; }
    public string GuestName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public DateOnly VisitDate { get; set; }
    public TimeOnly VisitTime { get; set; }
    public int GuestCount { get; set; }
    public int? TableNumber { get; set; }
    public string Preference { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;
    public BookingStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class RevenuePoint
{
    public string Label { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public decimal HeightPercent { get; set; }
}

public class DashboardViewData
{
    public decimal TodayRevenue { get; set; }
    public decimal RevenueDeltaPercent { get; set; }
    public int ActiveOrders { get; set; }
    public int ActiveOrdersDelta { get; set; }
    public int OccupiedTables { get; set; }
    public int TotalTables { get; set; }
    public int OccupiedPercent { get; set; }
    public int DishCount { get; set; }
    public int DishCountDelta { get; set; }
    public List<RevenuePoint> WeeklyRevenue { get; set; } = new();
    public decimal WeeklyMaxRevenue { get; set; }
}

public class ReportsViewData
{
    public decimal WeeklyRevenue { get; set; }
    public decimal WeeklyCosts { get; set; }
    public decimal WeeklyProfit { get; set; }
    public string TopDishName { get; set; } = string.Empty;
    public int TopDishOrders { get; set; }
    public decimal AverageReceipt { get; set; }
    public int CompletedOrders { get; set; }
    public int ConfirmedBookings { get; set; }
    public int CancelledBookings { get; set; }
    public int TotalGuests { get; set; }
    public List<(string DishName, int Quantity)> PopularDishes { get; set; } = new();
    public List<string> SummaryLines { get; set; } = new();
}
