namespace Управление_рестораном.Data.Entities;

public class БроньСущность
{
    public int ИдБрони { get; set; }
    public int ИдКлиента { get; set; }
    public int? ИдСтолика { get; set; }
    public DateOnly ДатаБрони { get; set; }
    public TimeOnly ВремяБрони { get; set; }
    public int КоличествоГостей { get; set; }
    public string? Предпочтение { get; set; }
    public string? Комментарий { get; set; }
    public string Статус { get; set; } = string.Empty;
    public DateTime ДатаСоздания { get; set; }

    public КлиентСущность Клиент { get; set; } = null!;
    public СтоликСущность? Столик { get; set; }
    public List<ЗаказСущность> Заказы { get; set; } = new();
}
