using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class HistoryModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public HistoryModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    [BindProperty(SupportsGet = true)]
    public HistoryPeriod Period { get; set; } = HistoryPeriod.Today;

    public IReadOnlyList<RestaurantOrder> Orders { get; private set; } = Array.Empty<RestaurantOrder>();

    public void OnGet()
    {
        Orders = _stateService.GetOrderHistory(Period, DateTime.Now);
    }

    public string GetStatusLabel(OrderStatus status) => status switch
    {
        OrderStatus.Completed => "Завершён",
        OrderStatus.Cancelled => "Отменён",
        _ => "В работе"
    };

    public string GetStatusClass(OrderStatus status) => status switch
    {
        OrderStatus.Completed => "badge-soft--success",
        OrderStatus.Cancelled => "badge-soft--danger",
        _ => "badge-soft--warning"
    };
}
