namespace Управление_рестораном.Data.Entities;

public class СтоликСущность
{
    public int ИдСтолика { get; set; }
    public int НомерСтолика { get; set; }
    public int Вместимость { get; set; }
    public string Статус { get; set; } = string.Empty;
    public int ЗанятоМест { get; set; }
    public DateTime? ВремяСтатуса { get; set; }
    public DateTime? ВремяБрони { get; set; }

    public List<БроньСущность> Брони { get; set; } = new();
    public List<ЗаказСущность> Заказы { get; set; } = new();
}
