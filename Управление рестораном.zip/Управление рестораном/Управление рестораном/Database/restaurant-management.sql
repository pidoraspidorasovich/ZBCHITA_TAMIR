/*
    Restaurant Management DB
    Run this script in SSMS after creating a database, or uncomment CREATE DATABASE.

    Example:
    CREATE DATABASE RestaurantManagement;
    GO
    USE RestaurantManagement;
    GO
*/

SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.vw_OrderProfit', 'V') IS NOT NULL DROP VIEW dbo.vw_OrderProfit;
GO

IF OBJECT_ID('dbo.OrderItems', 'U') IS NOT NULL DROP TABLE dbo.OrderItems;
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.Bookings', 'U') IS NOT NULL DROP TABLE dbo.Bookings;
IF OBJECT_ID('dbo.Dishes', 'U') IS NOT NULL DROP TABLE dbo.Dishes;
IF OBJECT_ID('dbo.DiningTables', 'U') IS NOT NULL DROP TABLE dbo.DiningTables;
IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL DROP TABLE dbo.Customers;
GO

CREATE TABLE dbo.Customers
(
    CustomerId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(120) NOT NULL,
    Phone NVARCHAR(30) NOT NULL,
    Notes NVARCHAR(400) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
GO

CREATE TABLE dbo.DiningTables
(
    TableId INT IDENTITY(1,1) PRIMARY KEY,
    TableNumber INT NOT NULL UNIQUE,
    Capacity INT NOT NULL,
    Status NVARCHAR(20) NOT NULL,
    OccupiedSeats INT NOT NULL DEFAULT 0,
    StatusSince DATETIME2 NULL,
    ReservedFor DATETIME2 NULL,
    CONSTRAINT CK_DiningTables_Capacity CHECK (Capacity > 0),
    CONSTRAINT CK_DiningTables_Status CHECK (Status IN ('Free', 'Occupied', 'Reserved')),
    CONSTRAINT CK_DiningTables_OccupiedSeats CHECK (OccupiedSeats >= 0 AND OccupiedSeats <= Capacity)
);
GO

CREATE TABLE dbo.Dishes
(
    DishId INT IDENTITY(1,1) PRIMARY KEY,
    DishName NVARCHAR(150) NOT NULL UNIQUE,
    Category NVARCHAR(30) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    CostPrice DECIMAL(10,2) NOT NULL,
    IsAvailable BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT CK_Dishes_Category CHECK (Category IN ('Soups', 'Salads', 'HotMeals', 'Desserts', 'Drinks')),
    CONSTRAINT CK_Dishes_Price CHECK (Price > 0),
    CONSTRAINT CK_Dishes_CostPrice CHECK (CostPrice >= 0)
);
GO

CREATE TABLE dbo.Bookings
(
    BookingId INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL,
    TableId INT NULL,
    VisitDate DATE NOT NULL,
    VisitTime TIME NOT NULL,
    GuestCount INT NOT NULL,
    Preference NVARCHAR(200) NULL,
    Comment NVARCHAR(500) NULL,
    Status NVARCHAR(20) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT FK_Bookings_Customers FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(CustomerId),
    CONSTRAINT FK_Bookings_DiningTables FOREIGN KEY (TableId) REFERENCES dbo.DiningTables(TableId),
    CONSTRAINT CK_Bookings_GuestCount CHECK (GuestCount > 0),
    CONSTRAINT CK_Bookings_Status CHECK (Status IN ('New', 'Confirmed', 'Cancelled'))
);
GO

CREATE TABLE dbo.Orders
(
    OrderId INT IDENTITY(1,1) PRIMARY KEY,
    TableId INT NOT NULL,
    BookingId INT NULL,
    CustomerId INT NULL,
    Status NVARCHAR(20) NOT NULL,
    Comment NVARCHAR(400) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    ClosedAt DATETIME2 NULL,
    CONSTRAINT FK_Orders_DiningTables FOREIGN KEY (TableId) REFERENCES dbo.DiningTables(TableId),
    CONSTRAINT FK_Orders_Bookings FOREIGN KEY (BookingId) REFERENCES dbo.Bookings(BookingId),
    CONSTRAINT FK_Orders_Customers FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(CustomerId),
    CONSTRAINT CK_Orders_Status CHECK (Status IN ('Cooking', 'Ready', 'Completed', 'Cancelled'))
);
GO

CREATE TABLE dbo.OrderItems
(
    OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
    OrderId INT NOT NULL,
    DishId INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(10,2) NOT NULL,
    UnitCost DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderId) REFERENCES dbo.Orders(OrderId) ON DELETE CASCADE,
    CONSTRAINT FK_OrderItems_Dishes FOREIGN KEY (DishId) REFERENCES dbo.Dishes(DishId),
    CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_OrderItems_UnitPrice CHECK (UnitPrice > 0),
    CONSTRAINT CK_OrderItems_UnitCost CHECK (UnitCost >= 0)
);
GO

CREATE INDEX IX_Bookings_VisitDate_VisitTime ON dbo.Bookings(VisitDate, VisitTime);
CREATE INDEX IX_Orders_Status_CreatedAt ON dbo.Orders(Status, CreatedAt DESC);
CREATE INDEX IX_OrderItems_OrderId ON dbo.OrderItems(OrderId);
GO

INSERT INTO dbo.DiningTables (TableNumber, Capacity, Status, OccupiedSeats, StatusSince, ReservedFor)
VALUES
(1, 2, 'Occupied', 2, DATEADD(MINUTE, -40, SYSDATETIME()), NULL),
(2, 4, 'Free', 0, NULL, NULL),
(3, 4, 'Occupied', 3, DATEADD(MINUTE, -25, SYSDATETIME()), NULL),
(4, 2, 'Free', 0, NULL, NULL),
(5, 6, 'Occupied', 5, DATEADD(MINUTE, -75, SYSDATETIME()), NULL),
(6, 4, 'Reserved', 0, NULL, DATEADD(MINUTE, 45, SYSDATETIME())),
(7, 2, 'Free', 0, NULL, NULL),
(8, 8, 'Occupied', 6, DATEADD(MINUTE, -50, SYSDATETIME()), NULL),
(9, 4, 'Free', 0, NULL, NULL),
(10, 2, 'Free', 0, NULL, NULL),
(11, 6, 'Free', 0, NULL, NULL),
(12, 4, 'Occupied', 4, DATEADD(MINUTE, -15, SYSDATETIME()), NULL),
(13, 2, 'Reserved', 0, NULL, DATEADD(HOUR, 1, SYSDATETIME())),
(14, 4, 'Free', 0, NULL, NULL),
(15, 6, 'Free', 0, NULL, NULL);
GO

INSERT INTO dbo.Dishes (DishName, Category, Price, CostPrice, IsAvailable)
VALUES
(N'Борщ украинский', 'Soups', 350, 120, 1),
(N'Том ям', 'Soups', 420, 170, 1),
(N'Крем-суп грибной', 'Soups', 320, 110, 1),
(N'Солянка мясная', 'Soups', 390, 145, 1),
(N'Цезарь с курицей', 'Salads', 450, 170, 1),
(N'Греческий салат', 'Salads', 390, 150, 1),
(N'Салат с ростбифом', 'Salads', 520, 230, 1),
(N'Оливье с языком', 'Salads', 430, 185, 1),
(N'Паста карбонара', 'HotMeals', 550, 210, 1),
(N'Стейк рибай', 'HotMeals', 1800, 980, 1),
(N'Филе судака', 'HotMeals', 740, 330, 1),
(N'Курица терияки', 'HotMeals', 610, 250, 1),
(N'Бефстроганов', 'HotMeals', 690, 310, 1),
(N'Бургер фирменный', 'HotMeals', 560, 240, 1),
(N'Картофель по-деревенски', 'HotMeals', 220, 75, 1),
(N'Тирамису', 'Desserts', 380, 140, 1),
(N'Чизкейк', 'Desserts', 350, 130, 1),
(N'Медовик', 'Desserts', 340, 120, 1),
(N'Фирменный чай', 'Drinks', 220, 60, 1),
(N'Лимонад облепиха', 'Drinks', 260, 70, 1),
(N'Морс клюквенный', 'Drinks', 180, 45, 1),
(N'Капучино', 'Drinks', 210, 55, 1);
GO

INSERT INTO dbo.Customers (FullName, Phone, Notes)
VALUES
(N'Алексей Петров', N'+7 (999) 123-45-67', N'Любит стол у окна'),
(N'Мария Соколова', N'+7 (921) 555-10-20', N'Иногда просит детский стул'),
(N'Игорь Данилов', N'+7 (903) 700-12-12', N'Обычно приходит большой компанией'),
(N'Екатерина Миронова', N'+7 (916) 400-31-20', N'Частый гость по пятницам'),
(N'Дмитрий Волков', N'+7 (905) 222-16-88', N'Просит тихую зону'),
(N'Ольга Самойлова', N'+7 (915) 777-44-11', NULL),
(N'Кирилл Жуков', N'+7 (926) 888-11-09', NULL),
(N'Анна Белова', N'+7 (903) 150-42-00', N'Аллергия на острое');
GO

INSERT INTO dbo.Bookings (CustomerId, TableId, VisitDate, VisitTime, GuestCount, Preference, Comment, Status, CreatedAt)
VALUES
(1, 6, CAST(GETDATE() AS DATE), '19:30', 4, N'У окна', N'День рождения, нужен тихий стол', 'Confirmed', DATEADD(HOUR, -3, SYSDATETIME())),
(2, 4, CAST(GETDATE() AS DATE), '20:00', 2, N'Спокойная зона', N'Нужен детский стул', 'New', DATEADD(HOUR, -2, SYSDATETIME())),
(3, 15, CAST(GETDATE() AS DATE), '21:15', 6, N'Большой стол', N'Позвонить за час', 'Cancelled', DATEADD(HOUR, -1, SYSDATETIME())),
(4, 13, DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '18:30', 2, N'У окна', N'Романтический ужин', 'Confirmed', DATEADD(HOUR, -5, SYSDATETIME())),
(5, 11, DATEADD(DAY, 1, CAST(GETDATE() AS DATE)), '20:30', 5, N'Поближе к сцене', N'Корпоративный ужин', 'New', DATEADD(HOUR, -4, SYSDATETIME()));
GO

INSERT INTO dbo.Orders (TableId, BookingId, CustomerId, Status, Comment, CreatedAt, ClosedAt)
VALUES
(5, NULL, NULL, 'Cooking', N'Без лука', DATEADD(MINUTE, -15, SYSDATETIME()), NULL),
(12, NULL, NULL, 'Cooking', N'Подать всё вместе', DATEADD(MINUTE, -8, SYSDATETIME()), NULL),
(3, NULL, NULL, 'Ready', N'Без перца', DATEADD(MINUTE, -5, SYSDATETIME()), NULL),
(4, NULL, 6, 'Completed', NULL, DATEADD(HOUR, -5, SYSDATETIME()), DATEADD(HOUR, -4, SYSDATETIME())),
(2, NULL, 5, 'Completed', NULL, DATEADD(DAY, -1, DATEADD(HOUR, 14, CAST(GETDATE() AS DATETIME2))), DATEADD(DAY, -1, DATEADD(HOUR, 15, CAST(GETDATE() AS DATETIME2)))),
(10, NULL, 7, 'Completed', NULL, DATEADD(DAY, -2, DATEADD(HOUR, 13, CAST(GETDATE() AS DATETIME2))), DATEADD(DAY, -2, DATEADD(HOUR, 14, CAST(GETDATE() AS DATETIME2)))),
(9, NULL, 8, 'Cancelled', N'Отмена по просьбе гостя', DATEADD(HOUR, -2, SYSDATETIME()), DATEADD(HOUR, -1, SYSDATETIME()));
GO

INSERT INTO dbo.OrderItems (OrderId, DishId, Quantity, UnitPrice, UnitCost)
VALUES
(1, 1, 1, 350, 120),
(1, 10, 1, 1800, 980),
(1, 16, 1, 380, 140),
(2, 5, 2, 450, 170),
(2, 9, 1, 550, 210),
(3, 2, 1, 420, 170),
(3, 17, 2, 350, 130),
(4, 9, 2, 550, 210),
(4, 19, 2, 220, 60),
(5, 5, 2, 450, 170),
(5, 16, 2, 380, 140),
(6, 10, 1, 1800, 980),
(6, 19, 2, 220, 60),
(7, 5, 2, 450, 170),
(7, 17, 1, 350, 130);
GO

CREATE VIEW dbo.vw_OrderProfit
AS
SELECT
    o.OrderId,
    t.TableNumber,
    o.Status,
    o.CreatedAt,
    o.ClosedAt,
    SUM(oi.Quantity * oi.UnitPrice) AS TotalRevenue,
    SUM(oi.Quantity * oi.UnitCost) AS TotalCost,
    SUM(oi.Quantity * oi.UnitPrice) - SUM(oi.Quantity * oi.UnitCost) AS TotalProfit
FROM dbo.Orders o
INNER JOIN dbo.DiningTables t ON t.TableId = o.TableId
INNER JOIN dbo.OrderItems oi ON oi.OrderId = o.OrderId
GROUP BY
    o.OrderId,
    t.TableNumber,
    o.Status,
    o.CreatedAt,
    o.ClosedAt;
GO
