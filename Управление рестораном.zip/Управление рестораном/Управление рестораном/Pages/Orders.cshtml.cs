using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class OrdersModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public OrdersModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    [BindProperty]
    public int SelectedTableNumber { get; set; }

    [BindProperty]
    public List<int> SelectedDishIds { get; set; } = new();

    [BindProperty]
    public string OrderComment { get; set; } = string.Empty;

    [TempData]
    public string? StatusMessage { get; set; }

    public IReadOnlyList<RestaurantOrder> Orders { get; private set; } = Array.Empty<RestaurantOrder>();
    public IReadOnlyList<Dish> AvailableDishes { get; private set; } = Array.Empty<Dish>();
    public IReadOnlyList<DiningTable> AvailableTables { get; private set; } = Array.Empty<DiningTable>();

    public void OnGet()
    {
        LoadData();
    }

    public IActionResult OnPostAdvance(int id)
    {
        _stateService.AdvanceOrder(id, DateTime.Now);
        return RedirectToPage();
    }

    public IActionResult OnPostCancel(int id)
    {
        _stateService.CancelOrder(id, DateTime.Now);
        return RedirectToPage();
    }

    public IActionResult OnPostAddOrder()
    {
        var error = _stateService.AddOrder(SelectedTableNumber, SelectedDishIds, OrderComment, DateTime.Now);
        StatusMessage = error ?? "Заказ добавлен.";
        return RedirectToPage();
    }

    public string GetOrderStatusLabel(OrderStatus status) => status switch
    {
        OrderStatus.Cooking => "Готовится",
        OrderStatus.Ready => "Готово",
        OrderStatus.Completed => "Завершён",
        OrderStatus.Cancelled => "Отменён",
        _ => "Неизвестно"
    };

    public string GetOrderBadgeClass(OrderStatus status) => status switch
    {
        OrderStatus.Cooking => "badge-soft--warning",
        OrderStatus.Ready => "badge-soft--success",
        OrderStatus.Completed => "badge-soft--success",
        OrderStatus.Cancelled => "badge-soft--danger",
        _ => "badge-soft--warning"
    };

    private void LoadData()
    {
        Orders = _stateService.GetActiveOrders();
        AvailableDishes = _stateService.GetAvailableDishes();
        AvailableTables = _stateService.GetTablesForOrders();
    }
}
