using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class IndexModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public IndexModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    public DashboardViewData Dashboard { get; private set; } = new();

    public void OnGet()
    {
        Dashboard = _stateService.GetDashboardData(DateTime.Now);
    }
}
