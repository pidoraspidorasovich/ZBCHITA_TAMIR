namespace Управление_рестораном.Data.Entities;

public class ЗаказСущность
{
    public int ИдЗаказа { get; set; }
    public int ИдСтолика { get; set; }
    public int? ИдБрони { get; set; }
    public int? ИдКлиента { get; set; }
    public string Статус { get; set; } = string.Empty;
    public string? Комментарий { get; set; }
    public DateTime ДатаСоздания { get; set; }
    public DateTime? ДатаЗакрытия { get; set; }

    public СтоликСущность Столик { get; set; } = null!;
    public БроньСущность? Бронь { get; set; }
    public КлиентСущность? Клиент { get; set; }
    public List<ПозицияЗаказаСущность> Позиции { get; set; } = new();
}
