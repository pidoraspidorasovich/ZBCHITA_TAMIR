namespace Управление_рестораном.Data.Entities;

public class КлиентСущность
{
    public int ИдКлиента { get; set; }
    public string ФИО { get; set; } = string.Empty;
    public string Телефон { get; set; } = string.Empty;
    public string? Заметка { get; set; }
    public DateTime ДатаСоздания { get; set; }

    public List<БроньСущность> Брони { get; set; } = new();
    public List<ЗаказСущность> Заказы { get; set; } = new();
}
