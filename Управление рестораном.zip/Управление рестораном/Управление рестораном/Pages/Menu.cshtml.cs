using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class MenuModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public MenuModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    [BindProperty(SupportsGet = true)]
    public string? Search { get; set; }

    [TempData]
    public string? StatusMessage { get; set; }

    [BindProperty]
    public string NewDishName { get; set; } = string.Empty;

    [BindProperty]
    public DishCategory NewDishCategory { get; set; }

    [BindProperty]
    public decimal NewDishPrice { get; set; }

    [BindProperty]
    public decimal NewDishCostPrice { get; set; }

    public IReadOnlyList<Dish> Dishes { get; private set; } = Array.Empty<Dish>();

    public void OnGet()
    {
        Dishes = _stateService.GetDishes(Search);
    }

    public IActionResult OnPostAddSampleDish()
    {
        StatusMessage = _stateService.AddSampleDish() ?? "Блюдо добавлено в меню.";
        return RedirectToPage(new { search = Search });
    }

    public IActionResult OnPostAddDish()
    {
        StatusMessage = _stateService.AddDish(NewDishName, NewDishCategory, NewDishPrice, NewDishCostPrice);
        return RedirectToPage(new { search = Search });
    }

    public IActionResult OnPostToggleAvailability(int id)
    {
        _stateService.ToggleDishAvailability(id);
        return RedirectToPage(new { search = Search });
    }

    public IActionResult OnPostChangePrice(int id, decimal delta)
    {
        _stateService.ChangeDishPrice(id, delta);
        return RedirectToPage(new { search = Search });
    }

    public IActionResult OnPostRemoveDish(int id)
    {
        _stateService.RemoveDish(id);
        return RedirectToPage(new { search = Search });
    }

    public string GetCategoryLabel(DishCategory category) => category switch
    {
        DishCategory.Soups => "Супы",
        DishCategory.Salads => "Салаты",
        DishCategory.HotMeals => "Горячие блюда",
        DishCategory.Desserts => "Десерты",
        DishCategory.Drinks => "Напитки",
        _ => "Другое"
    };
}
