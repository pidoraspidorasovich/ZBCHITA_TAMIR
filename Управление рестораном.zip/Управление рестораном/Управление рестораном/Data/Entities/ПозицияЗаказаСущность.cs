namespace Управление_рестораном.Data.Entities;

public class ПозицияЗаказаСущность
{
    public int ИдПозицииЗаказа { get; set; }
    public int ИдЗаказа { get; set; }
    public int ИдБлюда { get; set; }
    public int Количество { get; set; }
    public decimal ЦенаЗаЕдиницу { get; set; }
    public decimal СебестоимостьЗаЕдиницу { get; set; }

    public ЗаказСущность Заказ { get; set; } = null!;
    public БлюдоСущность Блюдо { get; set; } = null!;
}
