using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Управление_рестораном.Models;
using Управление_рестораном.Services;

namespace Управление_рестораном.Pages;

public class TablesModel : PageModel
{
    private readonly RestaurantStateService _stateService;

    public TablesModel(RestaurantStateService stateService)
    {
        _stateService = stateService;
    }

    public IReadOnlyList<DiningTable> Tables { get; private set; } = Array.Empty<DiningTable>();

    public int TotalCount => Tables.Count;
    public int OccupiedCount => Tables.Count(t => t.Status == TableStatus.Occupied);
    public int FreeCount => Tables.Count(t => t.Status == TableStatus.Free);
    public int ReservedCount => Tables.Count(t => t.Status == TableStatus.Reserved);

    public void OnGet()
    {
        Tables = _stateService.GetTables();
    }

    public IActionResult OnPostSetStatus(int number, TableStatus status)
    {
        _stateService.SetTableStatus(number, status, DateTime.Now);
        return RedirectToPage();
    }

    public string GetTableCardClass(TableStatus status) => status switch
    {
        TableStatus.Free => "table-card--free",
        TableStatus.Occupied => "table-card--busy",
        TableStatus.Reserved => "table-card--reserved",
        _ => string.Empty
    };

    public string GetTableStatusLabel(TableStatus status) => status switch
    {
        TableStatus.Free => "Свободен",
        TableStatus.Occupied => "Занят",
        TableStatus.Reserved => "Забронирован",
        _ => "Неизвестно"
    };

    public string GetCapacityLabel(DiningTable table) =>
        table.Status == TableStatus.Occupied ? $"{table.OccupiedSeats}/{table.Capacity}" : $"{table.Capacity} мест";

    public string GetDurationLabel(DateTime since)
    {
        var diff = DateTime.Now - since;
        if (diff.TotalMinutes < 60) return $"{Math.Max(1, (int)diff.TotalMinutes)} мин";
        return $"{(int)diff.TotalHours} ч {(int)diff.Minutes} мин";
    }

    public string GetReservationLabel(DateTime reservedFor)
    {
        var diff = reservedFor - DateTime.Now;
        if (diff.TotalMinutes < 60) return $"через {Math.Max(1, (int)diff.TotalMinutes)} мин";
        return $"через {Math.Max(1, (int)diff.TotalHours)} ч";
    }
}
