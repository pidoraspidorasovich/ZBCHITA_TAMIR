using Microsoft.EntityFrameworkCore;
using Управление_рестораном.Data.Entities;

namespace Управление_рестораном.Data;

public class RestaurantDbContext : DbContext
{
    public RestaurantDbContext(DbContextOptions<RestaurantDbContext> options) : base(options)
    {
    }

    public DbSet<КлиентСущность> Клиенты => Set<КлиентСущность>();
    public DbSet<СтоликСущность> Столики => Set<СтоликСущность>();
    public DbSet<БлюдоСущность> Блюда => Set<БлюдоСущность>();
    public DbSet<БроньСущность> Брони => Set<БроньСущность>();
    public DbSet<ЗаказСущность> Заказы => Set<ЗаказСущность>();
    public DbSet<ПозицияЗаказаСущность> ПозицииЗаказа => Set<ПозицияЗаказаСущность>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<КлиентСущность>().ToTable("Клиенты").HasKey(x => x.ИдКлиента);
        modelBuilder.Entity<СтоликСущность>().ToTable("Столики").HasKey(x => x.ИдСтолика);
        modelBuilder.Entity<БлюдоСущность>().ToTable("Блюда").HasKey(x => x.ИдБлюда);
        modelBuilder.Entity<БроньСущность>().ToTable("Брони").HasKey(x => x.ИдБрони);
        modelBuilder.Entity<ЗаказСущность>().ToTable("Заказы").HasKey(x => x.ИдЗаказа);
        modelBuilder.Entity<ПозицияЗаказаСущность>().ToTable("ПозицииЗаказа").HasKey(x => x.ИдПозицииЗаказа);

        modelBuilder.Entity<БроньСущность>()
            .HasOne(x => x.Клиент)
            .WithMany(x => x.Брони)
            .HasForeignKey(x => x.ИдКлиента);

        modelBuilder.Entity<БроньСущность>()
            .HasOne(x => x.Столик)
            .WithMany(x => x.Брони)
            .HasForeignKey(x => x.ИдСтолика);

        modelBuilder.Entity<ЗаказСущность>()
            .HasOne(x => x.Столик)
            .WithMany(x => x.Заказы)
            .HasForeignKey(x => x.ИдСтолика);

        modelBuilder.Entity<ЗаказСущность>()
            .HasOne(x => x.Бронь)
            .WithMany(x => x.Заказы)
            .HasForeignKey(x => x.ИдБрони);

        modelBuilder.Entity<ЗаказСущность>()
            .HasOne(x => x.Клиент)
            .WithMany(x => x.Заказы)
            .HasForeignKey(x => x.ИдКлиента);

        modelBuilder.Entity<ПозицияЗаказаСущность>()
            .HasOne(x => x.Заказ)
            .WithMany(x => x.Позиции)
            .HasForeignKey(x => x.ИдЗаказа);

        modelBuilder.Entity<ПозицияЗаказаСущность>()
            .HasOne(x => x.Блюдо)
            .WithMany(x => x.ПозицииЗаказа)
            .HasForeignKey(x => x.ИдБлюда);
    }
}
