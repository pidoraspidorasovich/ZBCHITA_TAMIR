namespace Управление_рестораном.Data.Entities;

public class БлюдоСущность
{
    public int ИдБлюда { get; set; }
    public string Название { get; set; } = string.Empty;
    public string Категория { get; set; } = string.Empty;
    public decimal Цена { get; set; }
    public decimal Себестоимость { get; set; }
    public bool Доступно { get; set; }
    public DateTime ДатаСоздания { get; set; }

    public List<ПозицияЗаказаСущность> ПозицииЗаказа { get; set; } = new();
}
