function formatRelativeTime(isoValue) {
  const createdAt = new Date(isoValue);
  const now = new Date();
  const diffMs = now - createdAt;
  const diffMinutes = Math.max(0, Math.floor(diffMs / 60000));

  if (diffMinutes < 1) {
    return "только что";
  }

  if (diffMinutes < 60) {
    return `${diffMinutes} мин назад`;
  }

  const hours = Math.floor(diffMinutes / 60);
  const minutes = diffMinutes % 60;

  if (minutes === 0) {
    return `${hours} ч назад`;
  }

  return `${hours} ч ${minutes} мин назад`;
}

function refreshLiveTimes() {
  document.querySelectorAll("[data-created-at]").forEach((element) => {
    const value = element.getAttribute("data-created-at");
    if (!value) {
      return;
    }

    element.textContent = formatRelativeTime(value);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  refreshLiveTimes();
  window.setInterval(refreshLiveTimes, 60000);
});
