# База данных

Файл [restaurant-management.sql](C:/Users/papab/source/repos/Управление рестораном/Управление рестораном/Database/restaurant-management.sql) создаёт базу для приложения.

Что уже есть:

- таблицы клиентов
- таблицы столиков
- таблицы блюд
- таблицы брони
- таблицы заказов
- таблицы позиций заказа
- стартовые данные

## Где менять подключение

Строка подключения лежит в файлах:

- [appsettings.json](C:/Users/papab/source/repos/Управление рестораном/Управление рестораном/appsettings.json)
- [appsettings.Development.json](C:/Users/papab/source/repos/Управление рестораном/Управление рестораном/appsettings.Development.json)

Нужный ключ:

```json
"ConnectionStrings": {
  "RestaurantDb": "Server=localhost\\SQLEXPRESS;Database=УправлениеРестораном;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

## Что менять

`Server=...`

- имя сервера SQL Server
- пример: `localhost\\SQLEXPRESS`
- пример: `.\\SQLEXPRESS`
- пример: `DESKTOP-123ABC\\SQLEXPRESS`

`Database=...`

- имя базы данных
- сейчас: `УправлениеРестораном`

## Пример для Windows-входа

```json
"RestaurantDb": "Server=localhost\\SQLEXPRESS;Database=УправлениеРестораном;Trusted_Connection=True;TrustServerCertificate=True;"
```

## Пример для логина и пароля

```json
"RestaurantDb": "Server=localhost\\SQLEXPRESS;Database=УправлениеРестораном;User Id=sa;Password=ТВОЙ_ПАРОЛЬ;TrustServerCertificate=True;"
```

## Если переносишь проект на другой компьютер

1. Установить SQL Server или SQL Server Express
2. Создать базу
3. Выполнить `restaurant-management.sql`
4. Открыть `appsettings.Development.json`
5. Поменять `Server=...`
6. При необходимости поменять `Database=...`
7. Запустить проект

## Если не знаешь имя сервера

В PowerShell можно посмотреть так:

```powershell
Get-Service | Where-Object { $_.Name -like 'MSSQL*' -or $_.Name -like 'SQL*' }
```

Если у тебя установлен `SQLEXPRESS`, чаще всего строка будет такой:

```json
"RestaurantDb": "Server=localhost\\SQLEXPRESS;Database=УправлениеРестораном;Trusted_Connection=True;TrustServerCertificate=True;"
```
